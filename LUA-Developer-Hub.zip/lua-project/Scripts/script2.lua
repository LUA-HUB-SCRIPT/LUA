-- Contoh script 2
local project = {
    name = "LUA",
    ready = true
}

print(project.name, project.ready)
