-- Contoh script 1
local message = "Hello from LUA"
print(message)
